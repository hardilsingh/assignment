﻿

using System;
using Nancy.Cryptography;

namespace SimpleCRUD.Code 
{
    public sealed class Test
    {
       
    }
   

}