# Simple-Windows-Froms-CRUD-using-MVC
Simple windows form CRUD using MVC and showind all Data with DataGridView

This is a Windows Forms APP CRUD with MVC Structure.

Please check this steps to get no further problems.

1 - make sure you have Microsoft SQL Server Installed and a login with windows authenticaion .

2 - Run the Database.sql file contained on this project to create the DB used on this example

3 - Check if the Database was created.

4 - Run the .sln file in the project and you are ready to go!
