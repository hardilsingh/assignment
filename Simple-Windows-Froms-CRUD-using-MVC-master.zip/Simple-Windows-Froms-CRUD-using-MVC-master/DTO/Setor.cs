﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class Setor
    {
        public int nldSetor { get; set; }

        public string sSetor { get; set; }
    }
}
