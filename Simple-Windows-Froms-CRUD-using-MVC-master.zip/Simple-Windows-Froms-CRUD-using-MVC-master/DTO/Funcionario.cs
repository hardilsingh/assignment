﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class Funcionario
    {
        public int nldFuncionario { get; set; }

        public string sNome { get; set; }

        public DateTime dNascimento { get; set; }

        public string sCPF { get; set; }

        public string sCargo { get; set; }

        public int nldSetor { get; set; }

        public string Money { get; set; }
    }
}
